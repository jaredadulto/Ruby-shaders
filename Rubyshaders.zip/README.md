# Rubyshaders · "Atardecer encantado"

Shaderpack personal para Minecraft Java 26.3 con Iris 1.11.7 (OpenGL).

## Instalar
1. Copia `Rubyshaders.zip` (sin descomprimir) a `.minecraft/shaderpacks/`.
2. En el juego: Opciones → Video → Shader Packs → Rubyshaders.
3. Si Sodium está en Vulkan, Iris pedirá cambiar a OpenGL: acepta y reabre el juego.
4. Tecla **R** (con el menú de shaders abierto) recarga tras editar archivos;
   en partida, **F3 + R** también recarga.

## Estructura
```
shaders/
├── shaders.properties   menú, perfiles, sliders
├── final.vsh / .fsh     pasada final: corrección de color
├── gbuffers_skytextured sol y luna de rubí (rombo a 45°)
├── shadow.vsh / .fsh    mapa de sombras
├── gbuffers_terrain/block/entities/water  luz + sombras + niebla
├── gbuffers_hand        objeto en la mano (brillo de hierro)
├── block.properties     vegetación y bloques de hierro
├── item.properties      objetos de hierro
├── lib/waving.glsl     viento
├── lib/
│   ├── settings.glsl    opciones (#define) y paleta rubí
│   ├── color.glsl       funciones de color
│   └── ruby.glsl        dibujo del rubí facetado
└── lang/                textos del menú (es_ES, en_US)
```

## Fases
- [x] Fase 1 — estructura y corrección de color final
- [x] Sol y luna de rubí facetado (rombo a 45°) — opcional, apagado por defecto
- [x] Brillo metálico en objetos y bloques de hierro
- [x] Etapa 2 — viento: césped, flores, cultivos y hojas se mueven (con sus sombras)
- [x] Better Grass rápido: pasto en todos los lados del césped y variantes
- [x] Luz dinámica (objetos de luz en la mano)
- [ ] Cielo propio (degradado de atardecer encantado)
- [x] Sombras reales con tinte violeta (sol de día, luna de noche)
- [ ] Fase 4 — agua, niebla y brillos mágicos
