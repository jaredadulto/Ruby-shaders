#version 330 compatibility
// =====================================================================
//  Rubyshaders · gbuffers_damagedblock.fsh — Grietas al romper un bloque
//  Se dibujan tal cual las da el juego: sin luz, sombras, viento ni
//  Better Grass, y mezcladas multiplicando como en vanilla.
// =====================================================================

uniform sampler2D gtexture;

in vec2 texcoord;
in vec4 glcolor;

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 fragColor;

void main() {
    vec4 color = texture(gtexture, texcoord) * glcolor;
    if (color.a < 0.01) discard;
    fragColor = color;
}
