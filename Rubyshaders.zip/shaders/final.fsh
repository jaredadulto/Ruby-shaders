#version 330 compatibility
// =====================================================================
//  Rubyshaders · final.fsh — Pasada final: corrección de color
//  "Atardecer encantado": realista cálido + fantasía saturada,
//  sombras violetas, luces doradas, noches lila-rosa.
// =====================================================================

#include "/lib/settings.glsl"
#include "/lib/color.glsl"

uniform sampler2D colortex0;   // imagen de la escena
uniform int   worldTime;       // 0..23999 (0 = amanecer, 6000 = mediodía, 12000 = ocaso)
uniform float viewWidth;
uniform float viewHeight;
uniform float rainStrength;    // 0..1
uniform int   isEyeInWater;    // 0 aire, 1 agua, 2 lava, 3 nieve polvo

in vec2 texcoord;

layout(location = 0) out vec4 fragColor;

// ---------------------------------------------------------------------
//  Momento del día
// ---------------------------------------------------------------------
float duskFactor() {          // atardecer y amanecer (hora dorada)
    float wt = float(worldTime);
    float dusk = 1.0 - smoothstep(0.0, 1.0, abs(wt - 12600.0) / 1600.0);
    float dDawn = min(abs(wt - 23400.0), wt + 600.0);   // con salto de 23999 a 0
    float dawn = 1.0 - smoothstep(0.0, 1.0, dDawn / 1400.0);
    return max(dusk, dawn);
}

float nightFactor() {
    float wt = float(worldTime);
    return smoothstep(12900.0, 13800.0, wt) * (1.0 - smoothstep(22300.0, 23200.0, wt));
}

// ---------------------------------------------------------------------
void main() {
    vec3 original = texture(colortex0, texcoord).rgb;

    #if DEBUG_SPLIT == 1
    if (texcoord.x < 0.5) {
        fragColor = vec4(original, 1.0);
        return;
    }
    #endif

    float dusk  = duskFactor();
    float night = nightFactor();
    float rain  = rainStrength;
    float water = (isEyeInWater == 1) ? 1.0 : 0.0;

    // ----- 1. A espacio lineal + exposición -----
    vec3 col = toLinear(original) * EXPOSURE;

    // ----- 2. Balance de blancos: cálido de día, dorado al ocaso, lila de noche -----
    float warm = (WARMTH + dusk * SUNSET_BOOST * 0.5) * (1.0 - night) * (1.0 - 0.6 * rain);
    col *= vec3(1.0 + 0.12 * warm, 1.0 + 0.02 * warm, 1.0 - 0.18 * warm);
    col  = applyTint(col, RUBY_LILAC_NIGHT, night * NIGHT_LILAC);

    // ----- 3. Split toning: sombras violetas, luces doradas -----
    float l = luminance(col);
    float shadowW    = 1.0 - smoothstep(0.0, 0.30, l);
    float highlightW = smoothstep(0.25, 0.90, l);
    float goldAmount = HIGHLIGHT_GOLD * (1.0 + dusk * SUNSET_BOOST) * (1.0 - 0.7 * night);
    col = applyTint(col, RUBY_VIOLET, shadowW * SHADOW_VIOLET * (1.0 + 0.5 * night));
    col = applyTint(col, RUBY_GOLD,   highlightW * goldAmount);

    // ----- 4. Mapeo de tonos -----
    #if TONEMAP_MODE == 1
        col = tonemapFilmic(col);
    #elif TONEMAP_MODE == 2
        col = tonemapReinhard(col);
    #endif

    // ----- 5. De vuelta a espacio gamma -----
    col = toGamma(col);

    // ----- 6. Contraste (alrededor del gris medio) -----
    col = mix(vec3(0.5), col, CONTRAST);

    // ----- 7. Saturación + vibrancia (menos bajo el agua y con lluvia) -----
    float satMul = mix(1.0, 0.85, max(water, rain * 0.6));
    col = saturateVibrance(col, SATURATION * satMul, VIBRANCE * (1.0 + 0.5 * dusk));

    // ----- 8. Negros elevados hacia violeta profundo (look de fantasía) -----
    col = clamp(col, 0.0, 1.0);
    col = mix(RUBY_DEEP_VIOLET * (LIFT_VIOLET / 0.1), vec3(1.0), col);

    // ----- 9. Viñeta morada -----
    vec2 uv = texcoord - 0.5;
    uv.x *= viewWidth / viewHeight;
    float vig = smoothstep(0.95, 0.25, length(uv));
    col *= mix(mix(vec3(1.0), RUBY_VIGNETTE * 2.0, 0.5), vec3(1.0), mix(1.0, vig, VIGNETTE_STRENGTH));

    // ----- 10. Dithering contra bandeado -----
    col += (hash12(gl_FragCoord.xy) - 0.5) / 255.0;

    fragColor = vec4(clamp(col, 0.0, 1.0), 1.0);
}
