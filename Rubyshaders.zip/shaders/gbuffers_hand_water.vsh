#version 330 compatibility
// Rubyshaders · gbuffers_hand_water.vsh — objetos translúcidos en la mano (vidrio, paneles...)
#define VERTEX
#define HAND
#define HAND_TRANSLUCENT
#include "/lib/gbuffers_main.glsl"
