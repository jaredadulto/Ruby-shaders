#version 330 compatibility
// =====================================================================
//  Rubyshaders · gbuffers_beaconbeam.vsh — Rayo del faro
// =====================================================================

out vec2 texcoord;
out vec4 glcolor;

void main() {
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;   // incluye el desplazamiento animado
    glcolor  = gl_Color;
    gl_Position = ftransform();
}
