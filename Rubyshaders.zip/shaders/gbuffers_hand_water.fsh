#version 330 compatibility
// Rubyshaders · gbuffers_hand_water.fsh — objetos translúcidos en la mano (vidrio, paneles...)
#define FRAGMENT
#define HAND
#define HAND_TRANSLUCENT
#include "/lib/gbuffers_main.glsl"
