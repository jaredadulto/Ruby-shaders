#version 330 compatibility
// Rubyshaders · gbuffers_entities_translucent.fsh — entidades semitransparentes (slime, etc.)
#define FRAGMENT
#define ENTITIES
#include "/lib/gbuffers_main.glsl"
