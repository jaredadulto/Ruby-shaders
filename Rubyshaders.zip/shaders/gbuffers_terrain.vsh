#version 430 compatibility
// Rubyshaders · gbuffers_terrain.vsh — ver lib/gbuffers_main.glsl
#define VERTEX
#define TERRAIN
#define TOP_MEMORY
#include "/lib/gbuffers_main.glsl"
