#version 330 compatibility
// =====================================================================
//  Rubyshaders · gbuffers_beaconbeam.fsh — Rayo del faro
//  Luz propia: sin sombras ni niebla, un poco más brillante que vanilla.
// =====================================================================

#include "/lib/settings.glsl"

uniform sampler2D gtexture;

in vec2 texcoord;
in vec4 glcolor;

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 fragColor;

void main() {
    vec4 color = texture(gtexture, texcoord) * glcolor;
    if (color.a < 0.01) discard;
    color.rgb *= BEACON_BRIGHTNESS;
    fragColor = color;
}
