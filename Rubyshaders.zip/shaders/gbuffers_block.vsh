#version 330 compatibility
// Rubyshaders · gbuffers_block.vsh — ver lib/gbuffers_main.glsl
#define VERTEX
#include "/lib/gbuffers_main.glsl"
