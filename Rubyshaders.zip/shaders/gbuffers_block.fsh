#version 330 compatibility
// Rubyshaders · gbuffers_block.fsh — ver lib/gbuffers_main.glsl
#define FRAGMENT
#include "/lib/gbuffers_main.glsl"
