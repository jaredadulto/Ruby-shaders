#version 330 compatibility
// Rubyshaders · gbuffers_entities.vsh — ver lib/gbuffers_main.glsl
#define VERTEX
#define ENTITIES
#include "/lib/gbuffers_main.glsl"
