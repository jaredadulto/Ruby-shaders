#version 330 compatibility
// =====================================================================
//  Rubyshaders · shadow.vsh — Dibuja el mundo visto desde el sol/luna
//  (las plantas se mueven aquí también, para que su sombra las siga)
// =====================================================================

#include "/lib/settings.glsl"
#include "/lib/shadows.glsl"
#include "/lib/waving.glsl"

uniform mat4 shadowModelView;
uniform mat4 shadowModelViewInverse;

in vec4 mc_Entity;
in vec4 mc_midTexCoord;

out vec2 texcoord;
out vec4 glcolor;

void main() {
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    glcolor  = gl_Color;
    vec2 lm  = clamp(((gl_TextureMatrix[1] * gl_MultiTexCoord1).xy - 1.0 / 32.0) * (16.0 / 15.0), 0.0, 1.0);

    vec4 shadowView = gl_ModelViewMatrix * gl_Vertex;
    vec3 playerPos  = (shadowModelViewInverse * shadowView).xyz;

    bool isTop = gl_MultiTexCoord0.t < mc_midTexCoord.t;
    playerPos += waveOffset(playerPos + cameraPosition, mc_Entity.x, isTop, lm.y);

    gl_Position = gl_ProjectionMatrix * (shadowModelView * vec4(playerPos, 1.0));
    gl_Position.xy = distortShadow(gl_Position.xy);
}
