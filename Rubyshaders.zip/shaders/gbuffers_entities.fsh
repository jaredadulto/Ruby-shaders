#version 330 compatibility
// Rubyshaders · gbuffers_entities.fsh — ver lib/gbuffers_main.glsl
#define FRAGMENT
#define ENTITIES
#include "/lib/gbuffers_main.glsl"
