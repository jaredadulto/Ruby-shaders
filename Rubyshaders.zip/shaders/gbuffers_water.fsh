#version 330 compatibility
// Rubyshaders · gbuffers_water.fsh — ver lib/gbuffers_main.glsl
#define FRAGMENT
#define TERRAIN
#include "/lib/gbuffers_main.glsl"
