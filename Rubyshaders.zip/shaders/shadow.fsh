#version 330 compatibility
// =====================================================================
//  Rubyshaders · shadow.fsh
// =====================================================================

uniform sampler2D gtexture;

in vec2 texcoord;
in vec4 glcolor;

layout(location = 0) out vec4 shadowColor;

void main() {
    vec4 c = texture(gtexture, texcoord) * glcolor;
    if (c.a < 0.1) discard;   // hojas y plantas proyectan su silueta real
    shadowColor = c;
}
