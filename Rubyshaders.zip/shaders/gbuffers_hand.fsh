#version 330 compatibility
// Rubyshaders · gbuffers_hand.fsh — objeto en la mano (ver lib/gbuffers_main.glsl)
#define FRAGMENT
#define HAND
#include "/lib/gbuffers_main.glsl"
