#version 330 compatibility
// Rubyshaders · gbuffers_water.vsh — ver lib/gbuffers_main.glsl
#define VERTEX
#define TERRAIN
#include "/lib/gbuffers_main.glsl"
