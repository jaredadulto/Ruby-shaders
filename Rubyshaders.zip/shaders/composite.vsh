#version 330 compatibility
// =====================================================================
//  Rubyshaders · composite.vsh — Quad de pantalla completa (nubes)
// =====================================================================

out vec2 texcoord;

void main() {
    gl_Position = ftransform();
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
}
