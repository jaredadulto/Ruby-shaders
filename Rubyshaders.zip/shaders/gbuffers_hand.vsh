#version 330 compatibility
// Rubyshaders · gbuffers_hand.vsh — objeto en la mano (ver lib/gbuffers_main.glsl)
#define VERTEX
#define HAND
#include "/lib/gbuffers_main.glsl"
