#version 330 compatibility
// =====================================================================
//  Rubyshaders · composite.fsh — Nubes redondeadas con sombra suave
//  Se dibujan después de todo el mundo, respetando la profundidad:
//  quedan bien tanto si estás debajo como encima de ellas.
// =====================================================================

#include "/lib/settings.glsl"
#include "/lib/clouds.glsl"

uniform sampler2D colortex0;
uniform sampler2D depthtex0;
uniform mat4  gbufferProjectionInverse;
uniform mat4  gbufferModelViewInverse;
uniform vec3  cameraPosition;
uniform vec3  shadowLightPosition;
uniform float frameTimeCounter;
uniform float sunAngle;
uniform float rainStrength;
uniform float cloudHeight;   // altura de las nubes del juego
uniform bool  hasSkylight;   // solo el Overworld tiene cielo con nubes

in vec2 texcoord;

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 fragColor;

float ditherNoise(vec2 p) {
    return fract(52.9829189 * fract(dot(p, vec2(0.06711056, 0.00583715))));
}

void main() {
    vec3 col = texture(colortex0, texcoord).rgb;

    #if CUSTOM_CLOUDS == 1
    if (hasSkylight) {
        float depth = texture(depthtex0, texcoord).r;
        vec4 vp = gbufferProjectionInverse * vec4(vec3(texcoord, depth) * 2.0 - 1.0, 1.0);
        vp /= vp.w;
        vec3  ppos      = (gbufferModelViewInverse * vec4(vp.xyz, 1.0)).xyz;
        bool  isSky     = depth >= 1.0;
        float sceneDist = isSky ? 1e9 : length(ppos);
        vec3  dir       = normalize(ppos);

        float yb = (cloudHeight > 0.0 && cloudHeight < 4096.0) ? cloudHeight : 192.0;
        float yt = yb + CLOUD_THICKNESS;
        float camY = cameraPosition.y;
        float coverage = CLOUD_COVERAGE + 0.25 * rainStrength;
        float time = frameTimeCounter;

        // ----- Color de la nube según la hora -----
        float elev  = sin(sunAngle * 6.2831853);
        float dayF  = smoothstep(-0.05, 0.15, elev);
        float duskF = 1.0 - smoothstep(0.0, 0.35, abs(elev));
        vec3 base = mix(vec3(0.20, 0.19, 0.30), vec3(0.98), dayF);
        base = mix(base, vec3(1.00, 0.78, 0.62), duskF * 0.55);
        base *= mix(1.0, 0.68, rainStrength);
        vec3 shade = base * vec3(0.74, 0.70, 0.88);   // sombra con tinte violeta

        // ----- Sombra de las nubes sobre el suelo -----
        #if CLOUD_GROUND_SHADOWS == 1
        if (!isSky) {
            vec3 wpos = ppos + cameraPosition;
            vec3 L = normalize(mat3(gbufferModelViewInverse) * shadowLightPosition);
            if (wpos.y < yb && L.y > 0.05) {
                vec3  sp  = wpos + L * ((yb + 0.5 * CLOUD_THICKNESS - wpos.y) / L.y);
                float f   = cloudField(sp.xz, coverage, time);
                float cov = smoothstep(cloudThreshold(0.5), cloudThreshold(0.5) + 0.25, f);
                float fade = (1.0 - smoothstep(96.0, 160.0, sceneDist)) * smoothstep(0.05, 0.25, L.y);
                col *= 1.0 - CLOUD_SHADOW_STRENGTH * cov * fade * (1.0 - 0.6 * rainStrength);
            }
        }
        #endif

        // ----- Recorrer la capa de nubes a lo largo de la mirada -----
        float t0, t1;
        if (abs(dir.y) < 1e-4) {
            t0 = 0.0; t1 = (camY > yb && camY < yt) ? CLOUD_DISTANCE : -1.0;
        } else {
            float ta = (yb - camY) / dir.y;
            float tb = (yt - camY) / dir.y;
            t0 = max(min(ta, tb), 0.0);
            t1 = max(ta, tb);
        }
        t1 = min(t1, min(sceneDist, CLOUD_DISTANCE));

        if (t1 > t0) {
            const int STEPS = 12;
            float stepLen = (t1 - t0) / float(STEPS);
            float t = t0 + stepLen * ditherNoise(gl_FragCoord.xy);
            vec3  cloudCol = vec3(0.0);
            float alpha = 0.0;

            for (int i = 0; i < STEPS; i++) {
                vec3  p    = cameraPosition + dir * t;
                float h    = clamp((p.y - yb) / CLOUD_THICKNESS, 0.0, 1.0);
                float need = cloudThreshold(h);
                float f    = cloudField(p.xz, coverage, time);
                float dens = smoothstep(need, need + 0.08, f);

                if (dens > 0.0) {
                    float fade = 1.0 - smoothstep(0.55 * CLOUD_DISTANCE, CLOUD_DISTANCE, t);
                    float a    = (1.0 - exp(-dens * stepLen * 0.9)) * fade;
                    // Sombra suave: más oscura abajo y en el centro de las nubes gruesas
                    float light = mix(0.55, 1.0, h) * mix(1.0, 0.85, smoothstep(need, need + 0.5, f));
                    light = mix(1.0, light, CLOUD_SHADING);
                    vec3 sc = mix(shade, base, light);
                    cloudCol += (1.0 - alpha) * a * sc;
                    alpha    += (1.0 - alpha) * a;
                    if (alpha > 0.98) break;
                }
                t += stepLen;
            }
            col = mix(col, col * (1.0 - alpha) + cloudCol, CLOUD_OPACITY);
        }
    }
    #endif

    fragColor = vec4(col, 1.0);
}
