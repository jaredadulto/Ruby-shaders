// =====================================================================
//  Rubyshaders · lib/gbuffers_main.glsl
//  Programa común para terreno, bloques, entidades, agua y mano:
//  luz de vanilla + sombras reales con tinte violeta + brillo de
//  hierro + niebla.
//  Cada archivo gbuffers_*.vsh/.fsh define VERTEX o FRAGMENT antes
//  de incluir este archivo (y TERRAIN / ENTITIES / HAND cuando aplica).
// =====================================================================

#include "/lib/settings.glsl"

uniform mat4 gbufferModelViewInverse;

// IDs de material (block.properties / item.properties)
#define MAT_IRON_BLOCK 10010.0   // vegetación: IDs 10001..10007
#define MAT_GRASS_BLOCK 10020.0  // césped y variantes (Better Grass)
// 10021 = tierra de cultivo seca, 10022 = húmeda, 10023 = camino de tierra:
// el shader recuerda la textura de su cara de arriba y la pone en los lados.
#define ITEM_IRON 20001
#define ITEM_GRAY_NOT_IRON 20002   // objetos grises que NO son hierro (piedra, grava...)
#define ENTITY_ITEM_HOLDER 30001   // objeto tirado, marco, marco brillante

// ---------------------------------------------------------------------
#ifdef VERTEX
// ---------------------------------------------------------------------

#ifdef TERRAIN
in vec4 mc_Entity;        // IDs de block.properties
in vec4 mc_midTexCoord;   // centro de la textura: sirve para saber qué vértices son "arriba"
uniform mat4 gbufferModelView;
#include "/lib/waving.glsl"
#endif

out vec2  texcoord;
out vec2  lmcoord;
out vec4  glcolor;
out vec3  viewPos;
out vec3  viewNormal;
out vec3  playerPos;
out vec3  worldNormal;
out float matId;     // 0 = normal, 1 = vegetación, 2 = bloque de hierro
flat out vec4  spriteRect;   // textura del bloque en el atlas: (mínimo, tamaño)
flat out float grassBlock;   // 1 = césped o variante
flat out float topSlot;      // 0..2 = bloque cuya cara de arriba se recuerda; -1 = no

void main() {
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord  = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    glcolor  = gl_Color;

    vec4 vp     = gl_ModelViewMatrix * gl_Vertex;
    playerPos   = (gbufferModelViewInverse * vp).xyz;
    viewNormal  = normalize(gl_NormalMatrix * gl_Normal);
    worldNormal = mat3(gbufferModelViewInverse) * viewNormal;

    matId = 0.0;
    spriteRect = vec4(0.0);
    grassBlock = 0.0;
    topSlot = -1.0;
    #ifdef TERRAIN
    vec2 halfSprite = abs(gl_MultiTexCoord0.xy - mc_midTexCoord.xy);
    spriteRect = vec4(mc_midTexCoord.xy - halfSprite, halfSprite * 2.0);
    if (mc_Entity.x == MAT_GRASS_BLOCK) grassBlock = 1.0;
    if (mc_Entity.x >= 10021.0 && mc_Entity.x <= 10023.0) topSlot = mc_Entity.x - 10021.0;

    if      (mc_Entity.x >= 10001.0 && mc_Entity.x <= 10007.0) matId = 1.0;
    else if (mc_Entity.x == MAT_IRON_BLOCK)                   matId = 2.0;

    // Viento: mueve césped, flores, cultivos y hojas
    vec2 lmN  = clamp((lmcoord - 1.0 / 32.0) * (16.0 / 15.0), 0.0, 1.0);
    bool isTop = gl_MultiTexCoord0.t < mc_midTexCoord.t;
    playerPos += waveOffset(playerPos + cameraPosition, mc_Entity.x, isTop, lmN.y);
    vp = gbufferModelView * vec4(playerPos, 1.0);
    #endif

    viewPos     = vp.xyz;
    gl_Position = gl_ProjectionMatrix * vp;
}

#endif

// ---------------------------------------------------------------------
#ifdef FRAGMENT
// ---------------------------------------------------------------------

uniform sampler2D gtexture;
uniform sampler2D lightmap;
uniform sampler2D shadowtex1;
uniform mat4  shadowModelView;
uniform mat4  shadowProjection;
uniform vec3  shadowLightPosition;
uniform float sunAngle;
uniform float rainStrength;
uniform vec3  fogColor;
uniform float fogStart;
uniform float fogEnd;
uniform float frameTimeCounter;
uniform float viewWidth;
uniform float viewHeight;
uniform vec3  cameraPosition;
uniform int   heldBlockLightValue;    // luz del objeto en la mano principal (0..15)
uniform int   heldBlockLightValue2;   // luz del objeto en la otra mano
#ifdef ENTITIES
uniform vec4  entityColor;   // destello rojo al recibir daño
#endif
#if defined ENTITIES || defined HAND
uniform int   currentRenderedItemId;   // ID de item.properties del objeto que se dibuja
#endif
#ifdef ENTITIES
uniform int   entityId;                // ID de entity.properties
#endif
#ifdef HAND
uniform int   heldItemId;    // mano principal (respaldo si lo anterior no llega)
uniform int   heldItemId2;   // mano secundaria
#endif

#define SHADOW_SAMPLING
#include "/lib/shadows.glsl"

in vec2  texcoord;
in vec2  lmcoord;
in vec4  glcolor;
in vec3  viewPos;
in vec3  viewNormal;
in vec3  playerPos;
in vec3  worldNormal;
in float matId;
flat in vec4  spriteRect;
flat in float grassBlock;
flat in float topSlot;

#ifdef TOP_MEMORY
// Memoria compartida entre fragmentos (y entre fotogramas): dónde está en el
// atlas la textura de arriba de cada bloque. Iris la crea con bufferObject.0.
layout(std430, binding = 0) buffer RubyTopSprites {
    vec4 topSprite[4];
};
#endif

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 fragColor;

// ---------------------------------------------------------------------
//  Brillo de hierro: reflejo plateado + destello que barre el objeto.
//  Solo afecta a los píxeles grises (el metal), no al mango de madera.
// ---------------------------------------------------------------------
vec3 ironShine(vec3 color, vec3 albedo, vec3 n, vec3 L, float lit, float lightLevel) {
    float mx = max(albedo.r, max(albedo.g, albedo.b));
    float mn = min(albedo.r, min(albedo.g, albedo.b));
    float lum = dot(albedo, vec3(0.2126, 0.7152, 0.0722));
    float metal = (1.0 - smoothstep(0.10, 0.24, mx - mn))    // poco color = metal
                * smoothstep(0.10, 0.35, lum);                 // no los contornos oscuros
    if (metal <= 0.0) return color;

    vec3 v = normalize(-viewPos);
    vec3 H = normalize(L + v);
    float spec    = pow(max(dot(n, H), 0.0), 24.0) * lit;
    float fresnel = pow(1.0 - abs(dot(n, v)), 2.0);

    // Reflejo falso del entorno: cielo claro arriba, suelo oscuro abajo.
    // Así el metal siempre tiene un degradado brillante, mires desde donde mires.
    vec3  R    = reflect(-v, n);
    float upR  = R.y * 0.5 + 0.5;
    vec3  env  = mix(vec3(0.35, 0.33, 0.40), vec3(1.0, 0.98, 1.0), smoothstep(0.35, 0.85, upR));

    // Destello diagonal ancho y frecuente que recorre el objeto
    float diag  = (gl_FragCoord.x + gl_FragCoord.y * 0.7) / viewHeight;
    float t     = fract(diag * 0.9 - frameTimeCounter * IRON_SHINE_SPEED * 0.45);
    float sweep = exp(-pow((t - 0.5) * 9.0, 2.0));

    float visibility = mix(0.45, 1.0, lightLevel);   // brilla también en cuevas, pero menos
    float k = metal * IRON_SHINE_STRENGTH;
    vec3 silver = vec3(0.94, 0.94, 1.00);            // plata con un toque lila

    color  = mix(color, color * env * 1.35, 0.55 * clamp(k, 0.0, 1.0));   // pulido
    color += silver * (spec * 0.9 + fresnel * 0.30 + sweep * 0.45) * k * visibility;
    return color;
}

// ---------------------------------------------------------------------
//  Better Grass (modo rápido): en las caras laterales del césped se
//  dibuja la parte de pasto de su propia textura, revuelta píxel a píxel,
//  para que se vea como la cara de arriba en todas las caras.
// ---------------------------------------------------------------------
float bgHash(vec2 p) {
    return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453);
}

vec4 betterGrassSample(vec3 blockPos) {
    ivec2 atlas  = textureSize(gtexture, 0);
    ivec2 sprite = max(ivec2(spriteRect.zw * vec2(atlas) + 0.5), ivec2(1));
    vec2  local  = clamp((texcoord - spriteRect.xy) / max(spriteRect.zw, vec2(1e-6)), 0.0, 0.9999);
    ivec2 px     = ivec2(local * vec2(sprite));

    // Solo las filas de arriba de la textura lateral (la franja de pasto)
    int rows = max(1, sprite.y * 3 / 16);
    vec2 seed = vec2(px) + blockPos.xz * 17.0 + blockPos.y * 31.0;
    int row  = min(int(bgHash(seed) * float(rows)), rows - 1);
    int col  = (px.x + int(bgHash(seed.yx + 7.3) * float(sprite.x))) % sprite.x;

    ivec2 base = ivec2(spriteRect.xy * vec2(atlas) + 0.5);
    return texelFetch(gtexture, base + ivec2(col, row), 0);
}

void main() {
    vec4 albedo = texture(gtexture, texcoord) * glcolor;

    #if defined TERRAIN && BETTER_GRASS == 1
    if (grassBlock > 0.5 && abs(worldNormal.y) < 0.5) {
        vec3 blockPos = floor(playerPos + cameraPosition - normalize(worldNormal) * 0.01);
        albedo = betterGrassSample(blockPos) * glcolor;
    }
    #endif

    #if defined TOP_MEMORY && BETTER_GRASS == 1
    if (topSlot > -0.5) {
        int slot = int(topSlot + 0.5);
        if (worldNormal.y > 0.5) {
            topSprite[slot] = spriteRect;            // cara de arriba: recordar su textura
        } else if (abs(worldNormal.y) < 0.5) {
            vec4 top = topSprite[slot];               // cara lateral: usar la de arriba
            if (top.z > 0.0) {
                vec2 local = clamp((texcoord - spriteRect.xy) / max(spriteRect.zw, vec2(1e-6)), 0.0, 1.0);
                albedo = texture(gtexture, top.xy + local * top.zw) * glcolor;
            }
        }
    }
    #endif
    if (albedo.a < 0.1) discard;
    vec4 color = albedo;

    #ifdef ENTITIES
    color.rgb = mix(color.rgb, entityColor.rgb, entityColor.a);
    #endif

    // Niveles de luz 0..1
    vec2 lm = clamp((lmcoord - 1.0 / 32.0) * (16.0 / 15.0), 0.0, 1.0);

    // ----- Luz dinámica: el objeto que llevas en la mano alumbra -----
    #if DYNAMIC_LIGHTS == 1
    {
        float held = float(max(heldBlockLightValue, heldBlockLightValue2));   // 0..15
        if (held > 0.0) {
            // La luz sale de la altura del pecho, no de los ojos
            float dist  = length(playerPos + vec3(0.0, 0.6, 0.0));
            float level = clamp(held * DYNAMIC_LIGHT_RANGE - dist, 0.0, 15.0) / 15.0;
            // Las caras que miran hacia ti reciben un poco más de luz
            float facing = max(dot(normalize(viewNormal), normalize(-viewPos)), 0.0);
            level *= mix(0.7, 1.0, facing);
            lm.x = max(lm.x, level);
        }
    }
    #endif

    // Luz de vanilla (antorchas + cielo), con la luz dinámica incluida
    vec2 lmLookup = vec2(lm.x, lm.y) * (15.0 / 16.0) + 1.0 / 32.0;
    vec3 lightColor = texture(lightmap, lmLookup).rgb;
    color.rgb *= lightColor;
    float blockLight = lm.x;
    float skyLight   = lm.y;

    vec3  n = normalize(viewNormal);
    vec3  L = normalize(shadowLightPosition);
    float elev = sin(sunAngle * 6.2831853);       // > 0 de día
    float dayF = smoothstep(-0.05, 0.05, elev);
    float horizonFade = smoothstep(0.0, 0.10, abs(elev));

    // ----- Sombras (no en la mano) -----
    float lit = 1.0;
    #ifndef HAND
    bool  isFoliage = matId > 0.5 && matId < 1.5;
    float NdotL = isFoliage ? 1.0 : dot(n, L);

    lit = 0.0;
    if (NdotL > 0.0) lit = sampleShadow(playerPos, normalize(worldNormal), isFoliage);
    lit *= smoothstep(0.0, 0.15, NdotL);          // caras de espaldas al sol = sombra

    float strength = SHADOW_STRENGTH
                   * mix(0.45, 1.0, dayF)
                   * horizonFade
                   * (1.0 - 0.75 * rainStrength)
                   * smoothstep(0.25, 0.85, skyLight)   // solo al aire libre
                   * (1.0 - 0.85 * blockLight);          // las antorchas iluminan la sombra

    float shadowAmt = (1.0 - lit) * strength;

    // Sombra violeta (tu estilo) y luz directa ligeramente dorada
    vec3 violet = vec3(0.42, 0.34, 0.66);
    violet *= 0.38 / dot(violet, vec3(0.2126, 0.7152, 0.0722));   // mismo brillo que el gris
    vec3 shadowMul = mix(vec3(0.38), violet, SHADOW_VIOLET_TINT);
    color.rgb *= mix(vec3(1.0), shadowMul, shadowAmt);

    float sunBoost = lit * dayF * horizonFade * smoothstep(0.25, 0.85, skyLight) * (1.0 - rainStrength);
    color.rgb *= 1.0 + sunBoost * vec3(0.10, 0.06, 0.00);
    #endif

    // ----- Brillo de hierro -----
    #if IRON_SHINE == 1
    bool isIron = false;
    #if defined ENTITIES || defined HAND
    if (currentRenderedItemId == ITEM_IRON) isIron = true;
    #endif
    #if defined ENTITIES && IRON_SHINE_ITEM_FALLBACK == 1
    // Respaldo para objetos tirados y en marcos: si Iris no dice qué objeto
    // es, brillan las partes grises tipo metal (ironShine ya ignora lo que
    // tiene color). Lo gris que no es hierro se excluye en item.properties.
    if (entityId == ENTITY_ITEM_HOLDER && currentRenderedItemId != ITEM_GRAY_NOT_IRON) isIron = true;
    #endif
    #ifdef HAND
    // Respaldo: mano derecha en pantalla = mano principal, izquierda = secundaria
    if (heldItemId  == ITEM_IRON && viewPos.x >  0.0) isIron = true;
    if (heldItemId2 == ITEM_IRON && viewPos.x <= 0.0) isIron = true;
    #endif
    #if defined TERRAIN && IRON_SHINE_BLOCKS == 1
    if (matId > 1.5) isIron = true;
    #endif
    if (isIron) {
        float sunLight = lit * dayF * horizonFade * skyLight * (1.0 - rainStrength);
        float lightLevel = dot(lightColor, vec3(0.2126, 0.7152, 0.0722));
        color.rgb = ironShine(color.rgb, albedo.rgb, n, L, sunLight, lightLevel);
        #if IRON_SHINE_DEBUG == 1
        color.rgb = mix(color.rgb, vec3(1.0, 0.0, 1.0), 0.6);   // prueba: el hierro detectado se pinta magenta
        #endif
    }
    #endif

    // ----- Niebla (no en la mano) -----
    #ifndef HAND
    float dist = length(viewPos);
    float fog  = clamp((dist - fogStart) / max(fogEnd - fogStart, 1e-3), 0.0, 1.0);
    color.rgb  = mix(color.rgb, fogColor, fog);
    #endif

    fragColor = color;
}

#endif
