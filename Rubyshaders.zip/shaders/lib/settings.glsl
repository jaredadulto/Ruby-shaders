// =====================================================================
//  Rubyshaders · "Atardecer encantado"
//  lib/settings.glsl — Opciones ajustables desde el menú de Iris
//  (Iris lee los valores posibles del comentario // [ ... ])
// =====================================================================

// ---------- Gradación de color ----------
#define EXPOSURE        1.00 // [0.60 0.70 0.80 0.90 1.00 1.10 1.20 1.30 1.40 1.50]
#define CONTRAST        1.08 // [0.90 0.95 1.00 1.04 1.08 1.12 1.16 1.20 1.30]
#define SATURATION      0.80 // [0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.30 1.40 1.50]
#define VIBRANCE        0.00 // [0.00 0.05 0.08 0.12 0.15 0.20 0.30 0.40 0.50 0.60]
#define TONEMAP_MODE    1    // [0 1 2]  0 = apagado, 1 = fílmico suave, 2 = Reinhard
#define LIFT_VIOLET     0.03 // [0.00 0.02 0.03 0.04 0.06 0.08 0.10]

// ---------- Atmósfera "Atardecer encantado" ----------
#define WARMTH            0.25 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.40 0.50]
#define SUNSET_BOOST      0.60 // [0.00 0.20 0.40 0.60 0.80 1.00]
#define NIGHT_LILAC       0.50 // [0.00 0.20 0.40 0.50 0.60 0.80 1.00]
#define SHADOW_VIOLET     0.30 // [0.00 0.10 0.20 0.30 0.35 0.40 0.50 0.60 0.80]
#define HIGHLIGHT_GOLD    0.30 // [0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.80]
#define VIGNETTE_STRENGTH 0.25 // [0.00 0.10 0.20 0.30 0.40 0.50 0.70]

// ---------- Sol y luna de rubí ----------
#define ROTATE_SUN_MOON 1  // [0 1]  1 = tu sol y tu luna girados 45° (rombo)
#define RUBY_SUN_MOON 0    // [0 1]  0 = sol y luna normales (los de tu paquete de recursos)
#define RUBY_SIZE    0.60 // [0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.80 0.90 1.00]
#define RUBY_GLOW    0.45 // [0.00 0.15 0.30 0.45 0.60 0.80]
#define RUBY_SPARKLE 1    // [0 1]

// ---------- Sombras ----------
#define SHADOW_STRENGTH 0.60 // [0.30 0.40 0.50 0.60 0.70 0.80 0.90]
#define SHADOW_SOFTNESS 1.50 // [0.50 1.00 1.50 2.00 3.00]
#define SHADOW_VIOLET_TINT 0.50 // [0.00 0.25 0.50 0.75 1.00]

// ---------- Brillo de hierro ----------
#define IRON_SHINE          0    // [0 1]
#define IRON_SHINE_STRENGTH 1.00 // [0.25 0.50 0.75 1.00 1.25 1.50 2.00]
#define IRON_SHINE_SPEED    1.00 // [0.50 0.75 1.00 1.50 2.00]
#define IRON_SHINE_BLOCKS   1    // [0 1]  1 = también bloques de hierro colocados
#define IRON_SHINE_ITEM_FALLBACK 1 // [0 1]  1 = brillo en objetos tirados/marcos aunque Iris no diga cuál es
#define IRON_SHINE_DEBUG    0    // [0 1]  1 = pinta de magenta lo que detecta como hierro

// ---------- Viento (Etapa 2) ----------
#define WAVING_PLANTS 1    // [0 1]
#define WAVING_LEAVES 1    // [0 1]
#define WAVE_STRENGTH 1.00 // [0.25 0.50 0.75 1.00 1.25 1.50 2.00]
#define WAVE_SPEED    1.00 // [0.50 0.75 1.00 1.25 1.50 2.00]

// ---------- Luz dinámica ----------
#define DYNAMIC_LIGHTS      1    // [0 1]
#define DYNAMIC_LIGHT_RANGE 1.00 // [0.50 0.75 1.00 1.25 1.50]

// ---------- Faro ----------
#define BEACON_BRIGHTNESS 1.20 // [0.80 1.00 1.20 1.50 2.00]

// ---------- Nubes ----------
#define CUSTOM_CLOUDS         1    // [0 1]  1 = nubes redondeadas propias (0 = las del juego)
#define CLOUD_COVERAGE        0.40 // [0.20 0.30 0.40 0.50 0.60 0.70]
#define CLOUD_THICKNESS       4.0  // [3.0 4.0 6.0 8.0]
#define CLOUD_SPEED           0.60 // [0.00 0.30 0.60 1.00 1.50 2.50]
#define CLOUD_SHADING         0.25 // [0.00 0.10 0.15 0.20 0.25 0.30 0.40 0.50 0.70 0.90 1.00]
#define CLOUD_OPACITY         0.95 // [0.70 0.80 0.90 0.95 1.00]
#define CLOUD_DISTANCE        640.0 // [384.0 512.0 640.0 768.0 1024.0]
#define CLOUD_GROUND_SHADOWS  1    // [0 1]
#define CLOUD_SHADOW_STRENGTH 0.08 // [0.03 0.05 0.08 0.10 0.15 0.20 0.25 0.35 0.50]

// ---------- Texturas ----------
#define BETTER_GRASS 1 // [0 1]  1 = la cara de pasto en todos los lados del césped

// ---------- Depuración ----------
#define DEBUG_SPLIT 0 // [0 1]  1 = mitad izquierda sin shader, para comparar

// ---------- Paleta de la marca (no son opciones del menú) ----------
const vec3 RUBY_VIOLET      = vec3(0.55, 0.32, 0.88);  // sombras violetas
const vec3 RUBY_GOLD        = vec3(1.00, 0.76, 0.36);  // luces doradas
const vec3 RUBY_LILAC_NIGHT = vec3(0.86, 0.80, 1.10);  // tinte lila-rosa nocturno
const vec3 RUBY_DEEP_VIOLET = vec3(0.10, 0.04, 0.18);  // negros elevados a violeta
const vec3 RUBY_VIGNETTE    = vec3(0.30, 0.12, 0.38);  // viñeta morada
