// =====================================================================
//  Rubyshaders · lib/shadows.glsl — Mapa de sombras distorsionado + PCF
// =====================================================================

// Ajustes que Iris lee directamente (también aparecen en el menú)
const int   shadowMapResolution     = 2048;  // [1024 2048 3072 4096]
const float shadowDistance          = 128.0; // [64.0 96.0 128.0 160.0 192.0 256.0]
const float shadowDistanceRenderMul = 1.0;
const bool  shadowtex1Nearest       = true;

// Distorsión: más resolución cerca del jugador, menos a lo lejos.
const float SHADOW_DISTORT = 0.10;

vec2 distortShadow(vec2 p) {
    return p / (length(p) + SHADOW_DISTORT);
}

#ifdef SHADOW_SAMPLING

const vec2 POISSON[12] = vec2[](
    vec2(-0.326, -0.406), vec2(-0.840, -0.074), vec2(-0.696,  0.457),
    vec2(-0.203,  0.621), vec2( 0.962, -0.195), vec2( 0.473, -0.480),
    vec2( 0.519,  0.767), vec2( 0.185, -0.893), vec2( 0.507,  0.064),
    vec2( 0.896,  0.412), vec2(-0.322, -0.933), vec2(-0.792, -0.598)
);

float shadowNoise(vec2 p) {
    return fract(52.9829189 * fract(dot(p, vec2(0.06711056, 0.00583715))));
}

// Devuelve 1 = iluminado por el sol/luna, 0 = en sombra.
float sampleShadow(vec3 playerPos, vec3 worldNormal, bool foliage) {
    // Tamaño aproximado de un texel de sombra en bloques, para el sesgo
    vec4 sc0 = shadowProjection * (shadowModelView * vec4(playerPos, 1.0));
    float factor = length(sc0.xy) + SHADOW_DISTORT;
    float texelWorld = (2.0 * shadowDistance / float(shadowMapResolution))
                     * factor * factor / SHADOW_DISTORT;

    // Sesgo por normal: evita el "acné" de sombras sobre las caras
    vec3 n = foliage ? vec3(0.0, 1.0, 0.0) : worldNormal;
    vec3 biased = playerPos + n * clamp(texelWorld * 1.3, 0.02, 0.6);

    vec4 sc = shadowProjection * (shadowModelView * vec4(biased, 1.0));
    sc.xy = distortShadow(sc.xy);
    vec3 uvz = sc.xyz * 0.5 + 0.5;

    if (any(lessThan(uvz.xy, vec2(0.0))) || any(greaterThan(uvz.xy, vec2(1.0))) || uvz.z > 1.0)
        return 1.0;

    // PCF con disco de Poisson rotado: bordes suaves sin patrón visible
    float ang = shadowNoise(gl_FragCoord.xy) * 6.2831853;
    mat2 rot = mat2(cos(ang), -sin(ang), sin(ang), cos(ang));
    float radius = SHADOW_SOFTNESS / float(shadowMapResolution);
    float bias = 0.00006;

    float lit = 0.0;
    for (int i = 0; i < 12; i++) {
        vec2 off = rot * POISSON[i] * radius;
        float depth = texture(shadowtex1, uvz.xy + off).r;
        lit += step(uvz.z - bias, depth);
    }
    lit /= 12.0;

    // Desvanecer en el borde de la distancia de sombras
    float edge = smoothstep(0.85, 1.0, length(playerPos.xz) / shadowDistance);
    return mix(lit, 1.0, edge);
}

#endif
