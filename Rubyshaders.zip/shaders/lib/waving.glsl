// =====================================================================
//  Rubyshaders · lib/waving.glsl — Viento para césped, flores, hojas y heno
//  Se usa en el terreno y en el mapa de sombras, para que la sombra
//  de cada planta se mueva igual que la planta.
// =====================================================================

uniform vec3  cameraPosition;
uniform float frameTimeCounter;
uniform float rainStrength;

// Desplazamiento en bloques para un vértice.
//  worldPos : posición absoluta del vértice
//  id       : valor de mc_Entity.x
//  isTop    : true si es un vértice de la parte de arriba de la textura
//  sky      : luz del cielo 0..1 (bajo techo casi no hay viento)
vec3 waveOffset(vec3 worldPos, float id, bool isTop, float sky) {
    float weight = 0.0;
    float amp    = 0.0;

    #if WAVING_PLANTS == 1
    if (id == 10003.0) { weight = isTop ? 1.0 : 0.0; amp = 0.14; }   // planta baja
    if (id == 10005.0) { weight = isTop ? 0.5 : 0.0; amp = 0.16; }   // doble, abajo
    if (id == 10006.0) { weight = isTop ? 1.0 : 0.5; amp = 0.16; }   // doble, arriba
    #endif
    #if WAVING_LEAVES == 1
    if (id == 10007.0) { weight = 1.0; amp = 0.06; }                  // hojas: todo el bloque
    if (id == 10008.0) { weight = 1.0; amp = 0.04; }                  // heno: un poco menos
    #endif
    if (weight == 0.0) return vec3(0.0);

    float t    = frameTimeCounter * WAVE_SPEED;
    float wind = (1.0 + 1.6 * rainStrength) * mix(0.25, 1.0, smoothstep(0.2, 0.7, sky));

    // Ráfagas lentas que recorren el paisaje en una dirección
    vec2  dir   = normalize(vec2(1.0, 0.45));
    float along = dot(worldPos.xz, dir);
    float gust  = 0.55 + 0.45 * sin(t * 0.55 - along * 0.12);

    // Balanceo principal + temblor fino
    float sway = sin(t * 1.6 - along * 0.35 + worldPos.y * 0.25) * 0.65
               + sin(t * 2.9 + worldPos.x * 0.8 + worldPos.z * 0.6) * 0.25;
    float side = sin(t * 1.2 + worldPos.x * 0.5 - worldPos.z * 0.4) * 0.35
               + sin(t * 3.4 + worldPos.z * 1.1) * 0.15;

    vec3 off = vec3(dir.x * sway - dir.y * side, 0.0, dir.y * sway + dir.x * side);

    #if WAVING_LEAVES == 1
    if (id == 10007.0 || id == 10008.0) {
        // Las hojas (y el heno) además "tiemblan" en vertical y con fase por vértice
        float rustle = sin(t * 4.2 + dot(worldPos, vec3(1.7, 2.3, 1.3)));
        off += vec3(0.25, 0.45, 0.25) * rustle;
    }
    #endif

    return off * amp * weight * gust * wind * WAVE_STRENGTH;
}
