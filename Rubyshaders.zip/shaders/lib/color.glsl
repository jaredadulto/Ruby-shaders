// =====================================================================
//  Rubyshaders · lib/color.glsl — Funciones de color reutilizables
// =====================================================================

float luminance(vec3 c) {
    return dot(c, vec3(0.2126, 0.7152, 0.0722));
}

vec3 toLinear(vec3 c) { return pow(max(c, 0.0), vec3(2.2)); }
vec3 toGamma(vec3 c)  { return pow(max(c, 0.0), vec3(1.0 / 2.2)); }

// Curva fílmica (aprox. ACES de Narkowicz), normalizada para que el
// blanco vanilla siga en blanco y el gris medio no cambie: solo añade
// un "pie" suave en sombras y un hombro en las luces.
vec3 acesCurve(vec3 x) {
    return clamp((x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14), 0.0, 1.0);
}
vec3 tonemapFilmic(vec3 c) {
    const float W = 0.55;
    return acesCurve(c * W) / acesCurve(vec3(W));
}

vec3 tonemapReinhard(vec3 c) {
    const float W = 1.5; // punto blanco
    const float norm = (1.0 + 1.0 / (W * W)) / 2.0; // valor de la curva en 1.0
    return c * (1.0 + c / (W * W)) / (1.0 + c) / norm;
}

// Multiplica por un tinte normalizado: cambia el matiz sin cambiar el brillo.
vec3 applyTint(vec3 c, vec3 tint, float amount) {
    vec3 t = tint / max(luminance(tint), 1e-4);
    return c * mix(vec3(1.0), t, clamp(amount, 0.0, 1.0));
}

// Saturación + vibrancia (la vibrancia sube más los colores apagados).
vec3 saturateVibrance(vec3 c, float sat, float vib) {
    float l  = luminance(c);
    float mx = max(c.r, max(c.g, c.b));
    float mn = min(c.r, min(c.g, c.b));
    float chroma = mx - mn;
    float s = sat * (1.0 + vib * (1.0 - chroma));
    return mix(vec3(l), c, s);
}

// Ruido para romper el bandeado de 8 bits en cielos y degradados.
float hash12(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}
