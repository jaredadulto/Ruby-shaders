// =====================================================================
//  Rubyshaders · lib/clouds.glsl — Nubes redondeadas propias
//  Cada celda de 12 bloques (como vanilla) puede tener una "bola" de nube;
//  las bolas vecinas se funden entre sí, así los bordes quedan curvos.
// =====================================================================

float cloudHash(vec2 p) {
    p = fract(p * vec2(123.34, 456.21));
    p += dot(p, p + 45.32);
    return fract(p.x * p.y);
}

// Valor del campo de nube en un punto (x, z) del mundo
float cloudField(vec2 xz, float coverage, float time) {
    vec2 q  = (xz + vec2(time * CLOUD_SPEED, 0.0)) / 12.0;
    vec2 c0 = floor(q);
    float f = 0.0;
    for (int j = -1; j <= 1; j++) {
        for (int i = -1; i <= 1; i++) {
            vec2  c = c0 + vec2(i, j);
            float h = cloudHash(c);
            if (h < coverage) {
                vec2  center = c + 0.5 + (vec2(cloudHash(c + 17.1), cloudHash(c + 31.7)) - 0.5) * 0.3;
                float r  = 0.80 + 0.35 * cloudHash(c + 5.3);
                vec2  d  = q - center;
                float d2 = dot(d, d) / (r * r);
                float k  = max(0.0, 1.0 - d2);
                f += k * k;
            }
        }
    }
    return f;
}

// Umbral según la altura dentro de la capa (0 abajo, 1 arriba):
// más alto en los extremos → la nube se adelgaza arriba y abajo (bordes redondos).
float cloudThreshold(float h) {
    float e = 2.0 * h - 1.0;
    return 0.35 + 0.45 * e * e;
}
