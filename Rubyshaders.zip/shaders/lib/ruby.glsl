// =====================================================================
//  Rubyshaders · lib/ruby.glsl — Rubí facetado en forma de rombo
//  q: coordenadas locales del cuadro del sol/luna, de -1 a 1.
//  El rombo |x| + |y| < 1 es el cuadrado de vanilla girado 45°.
// =====================================================================

const float RUBY_PI = 3.14159265;

vec4 rubyGem(vec2 q, bool isSun, float time) {
    q /= RUBY_SIZE;
    float d = abs(q.x) + abs(q.y);            // "distancia" en forma de rombo

    // Paleta: sol rojo-dorado, luna lila-rosa
    vec3 deep  = isSun ? vec3(0.62, 0.03, 0.08) : vec3(0.52, 0.22, 0.58);
    vec3 mid   = isSun ? vec3(0.95, 0.22, 0.10) : vec3(0.90, 0.55, 0.88);
    vec3 light = isSun ? vec3(1.00, 0.80, 0.36) : vec3(1.00, 0.86, 0.94);
    vec3 glowC = isSun ? vec3(1.00, 0.42, 0.14) : vec3(0.95, 0.62, 0.95);

    // ----- Resplandor fuera del rombo -----
    float glow = exp(-max(d - 1.0, 0.0) * 6.0) * RUBY_GLOW;
    if (d > 1.0) return vec4(glowC, glow);

    // ----- Facetas -----
    const float TABLE = 0.40;   // mesa central (cara plana)
    const float CROWN = 0.74;   // anillo de la corona
    vec3 L = normalize(vec3(-0.45, 0.55, 0.70));   // luz desde arriba-izquierda

    vec3  n;
    float edge;
    if (d < TABLE) {
        n = vec3(0.0, 0.0, 1.0);
        edge = TABLE - d;
    } else {
        float ang    = atan(q.y, q.x);
        float sectF  = (ang + RUBY_PI) / (RUBY_PI / 4.0);   // 8 sectores
        float sector = floor(sectF);
        float ca     = -RUBY_PI + (sector + 0.5) * (RUBY_PI / 4.0);
        float k      = (mod(sector, 2.0) < 0.5) ? 0.55 : 0.95;  // facetas alternas
        k *= (d > CROWN) ? 1.7 : 1.0;                            // borde más inclinado
        n = normalize(vec3(cos(ca) * k, sin(ca) * k, 1.0));

        float f = fract(sectF);
        float angEdge  = min(f, 1.0 - f) * (RUBY_PI / 4.0) * length(q);
        float ringEdge = min(abs(d - TABLE), abs(d - CROWN));
        edge = min(angEdge, ringEdge);
    }
    edge = min(edge, 1.0 - d);                       // contorno exterior

    float shade = 0.20 + 0.80 * max(dot(n, L), 0.0);
    float spec  = pow(max(dot(reflect(-L, n), vec3(0.0, 0.0, 1.0)), 0.0), 24.0);

    vec3 col = mix(deep, mid, smoothstep(0.25, 0.70, shade));
    col = mix(col, light, smoothstep(0.80, 1.00, shade));
    col += light * spec * 0.7;

    // Aristas brillantes entre facetas
    float lines = 1.0 - smoothstep(0.0, 0.022, edge);
    col = mix(col, light, lines * 0.45);

    // ----- Destello -----
    #if RUBY_SPARKLE == 1
    vec2  sp    = q - vec2(-0.16, 0.20);
    float pulse = 0.55 + 0.45 * sin(time * 1.7);
    float star  = max(0.0, 1.0 - abs(sp.x) * 30.0) * max(0.0, 1.0 - abs(sp.y) * 5.0)
                + max(0.0, 1.0 - abs(sp.y) * 30.0) * max(0.0, 1.0 - abs(sp.x) * 5.0);
    col += vec3(1.0, 0.97, 0.92) * star * pulse;
    #endif

    if (!isSun) col *= 0.85;   // la luna un poco más tenue

    // Borde suavizado (antialias) que se funde con el resplandor
    float a = 1.0 - smoothstep(0.97, 1.0, d);
    col = mix(glowC, col, a);
    return vec4(col, max(a, glow));
}
