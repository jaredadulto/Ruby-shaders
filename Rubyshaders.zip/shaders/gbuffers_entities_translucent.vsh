#version 330 compatibility
// Rubyshaders · gbuffers_entities_translucent.vsh — entidades semitransparentes (slime, etc.)
#define VERTEX
#define ENTITIES
#include "/lib/gbuffers_main.glsl"
