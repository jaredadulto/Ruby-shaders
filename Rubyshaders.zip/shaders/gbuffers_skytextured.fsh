#version 330 compatibility
// =====================================================================
//  Rubyshaders · gbuffers_skytextured.fsh
//  Gira 45° (rombo) el sol y la luna de tu paquete de recursos,
//  o los reemplaza por rubíes facetados si RUBY_SUN_MOON = 1.
//  Las coordenadas se calculan a partir de la dirección del sol/luna,
//  así funciona con cualquier paquete de recursos y fase lunar.
// =====================================================================

#include "/lib/settings.glsl"
#include "/lib/ruby.glsl"

uniform sampler2D gtexture;
uniform int   renderStage;
uniform vec3  sunPosition;
uniform vec3  moonPosition;
uniform mat4  gbufferModelView;
uniform float frameTimeCounter;

in vec2 texcoord;
in vec4 glcolor;
in vec3 viewPos;

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 fragColor;

void main() {
    vec4 tex = texture(gtexture, texcoord) * glcolor;

    #if RUBY_SUN_MOON == 0 && ROTATE_SUN_MOON == 0
    // Sol y luna sin cambios: se dibujan tal cual los da el juego
    fragColor = tex;
    return;
    #endif
    vec3 v   = normalize(viewPos);
    vec3 sunDir  = normalize(sunPosition);
    vec3 moonDir = normalize(moonPosition);

    // 0 = otra cosa del cielo, 1 = sol, 2 = luna
    int body = 0;
    #ifdef MC_RENDER_STAGE_SUN
        if      (renderStage == MC_RENDER_STAGE_SUN)  body = 1;
        else if (renderStage == MC_RENDER_STAGE_MOON) body = 2;
    #else
        if      (dot(v, sunDir)  > 0.9) body = 1;
        else if (dot(v, moonDir) > 0.9) body = 2;
    #endif

    if (body == 0) {           // cielo del End, etc.: se dibuja normal
        if (tex.a < 0.01) discard;
        fragColor = tex;
        return;
    }

    // Plano tangente al astro, alineado con los bordes del cuadro vanilla
    vec3 c     = (body == 1) ? sunDir : moonDir;
    vec3 northSouth = mat3(gbufferModelView) * vec3(0.0, 0.0, 1.0);
    vec3 t1    = normalize(northSouth - c * dot(northSouth, c));
    vec3 t2    = cross(c, t1);
    vec3 p     = v / max(dot(v, c), 1e-3) - c;

    float halfSize = (body == 1) ? 0.30 : 0.20;   // tamaños de vanilla (30 y 20 a distancia 100)
    vec2  q = vec2(dot(p, t2), dot(p, t1)) / halfSize;

    #if RUBY_SUN_MOON == 1
    vec4 ruby = rubyGem(q, body == 1, frameTimeCounter);
    ruby.a *= glcolor.a;       // se desvanece con la lluvia, como en vanilla
    if (ruby.a < 0.003) discard;
    fragColor = ruby;

    #else
    // ----- Tu propio sol/luna, girado 45° (rombo) -----
    // La textura y q cambian de forma lineal sobre el cuadro, así que con
    // sus derivadas sabemos qué punto de la textura cae en cualquier q.
    mat2 dQ = mat2(dFdx(q), dFdy(q));
    mat2 dT = mat2(dFdx(texcoord), dFdy(texcoord));

    // Punto de la textura original que se ve aquí al girarla 45°:
    // (x + y, y - x) es la rotación de 45° ya escalada por raíz de 2,
    // para que las puntas del rombo toquen los bordes del cuadro.
    vec2 qr = vec2(q.x + q.y, q.y - q.x);
    if (max(abs(qr.x), abs(qr.y)) > 1.0) discard;   // fuera del rombo

    vec2 uv = texcoord;
    if (abs(determinant(dQ)) > 1e-12) uv += dT * inverse(dQ) * (qr - q);
    fragColor = texture(gtexture, uv) * glcolor;
    #endif
}
